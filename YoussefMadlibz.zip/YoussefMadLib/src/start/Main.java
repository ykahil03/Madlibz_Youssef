/**
 * Name: Youssef
 * Date: Feb. 20, 2020
 * Project: YoussefMadLib
 * Package: start
 * File: Main.java
 * Description:
 */
package start;

import java.util.Scanner;

/**
 * @author s448352
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		 //Get Variables
		System.out.println("give me a silly name");
		String s_name = in.nextLine();
		System.out.println("give me a silly word");
		String s_word= in.nextLine();
		System.out.println("give me a verb");
		String verb1= in.nextLine();
		System.out.println("give me a noun");
		String noun1= in.nextLine();
		System.out.println("give me a plural body part");
		String pluBody= in.nextLine();
		System.out.println("give me a female name");
		String femName= in.nextLine();
		System.out.println("give me a verb ending with ed");
		String ed_Verb= in.nextLine();
		System.out.println("give me another noun");
		String noun2= in.nextLine();
		System.out.println("give me a plural noun");
		String pluNoun= in.nextLine();
		System.out.println("give me another verb");
		String verb2= in.nextLine();
		System.out.println("give me another noun");
		String noun3= in.nextLine();
		System.out.println("give me an occupation");
		String occup= in.nextLine();
		System.out.println("give me a Number");
		int num2= in.nextInt();
		System.out.println("give me another Verb");
		String verb3= in.nextLine();
		in.nextLine();
		System.out.println("Give me a silly word");
		String s_word2= in.nextLine();
		System.out.println("Give me a silly name");
		String s_name2= in.nextLine();
	
		
			
		
		
		//Write out the Story
		System.out.println("Dear Mr. and Mrs. "+s_name+" Sillyword1,");
		System.out.println("Will you let me "+verb1+" your "+noun1+"?");
		System.out.println("Ever since I have laid "+pluBody+" on "+femName+",");
		System.out.println("I have "+ed_Verb+" madly in love with her. I wish that she will be the "+noun2+" of my "+pluNoun+" and that someday we will Verb2 happily ever after.");
		System.out.println("I have a "+noun3+" as a/an "+occup+" that pays $"+num2+" each month.");
		System.out.println("I promise to "+verb3+" "+femName+" with kindness and respect.");
		System.out.println("Sincerely,");
		System.out.println(""+s_word+" "+s_name2+"");
		

	}

}
